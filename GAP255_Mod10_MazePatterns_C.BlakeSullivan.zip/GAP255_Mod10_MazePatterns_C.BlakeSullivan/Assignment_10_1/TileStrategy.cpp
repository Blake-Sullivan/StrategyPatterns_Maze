#include <iostream>
#include <utility>

#include "TileStrategy.h"
#include "Player.h"
#include "Tile.h"
#include "World.h"

// Allows access to global variable declared in another CPP.
extern World* g_pWorld;

// Constructors
TileStrategy::TileStrategy(Tile* tile)
    : m_tile(tile)
{ }
EmptyStrategy::EmptyStrategy(Tile* tile) : TileStrategy(tile) {}
EndStrategy::EndStrategy(Tile* tile) : TileStrategy(tile) {}
TreasureStrategy::TreasureStrategy(Tile* tile) : TileStrategy(tile) {}
BombStrategy::BombStrategy(Tile* tile) : TileStrategy(tile) {}
MimicStrategy::MimicStrategy(Tile* tile) : BombStrategy(tile) {}
ExplodedStrategy::ExplodedStrategy(Tile* tile) : TileStrategy(tile) {}


//////////////////////////////////////////////////////////////
// Floor Tile Strategy - aka "empty"
//////////////////////////////////////////////////////////////
void EmptyStrategy::Draw()
{
    std::cout << ".";
}
void EmptyStrategy::OnEnter(Player* pPlayer)
{
    // nothing
}

//////////////////////////////////////////////////////////////
// End Tile Strategy
//////////////////////////////////////////////////////////////
void EndStrategy::Draw()
{
    std::cout << "H";
}
void EndStrategy::OnEnter(Player* pPlayer)
{
    g_pWorld->EndGame();
}

//////////////////////////////////////////////////////////////
// Treasure Tile Strategy
//////////////////////////////////////////////////////////////
const TreasureStrategy::TreasureRange TreasureStrategy::s_treasureRange(50, 150);

void TreasureStrategy::Draw()
{
    std::cout << "$";
}
void TreasureStrategy::OnEnter(Player* pPlayer)
{
    pPlayer->AddGold(rand() % (s_treasureRange.second - s_treasureRange.first) + s_treasureRange.first);
    // Treasure becomes "Empty" --> set new Strategy
    m_tile->SetStrategy(new EmptyStrategy(m_tile));
}

//////////////////////////////////////////////////////////////
// Bomb Tile Strategy
//////////////////////////////////////////////////////////////
const BombStrategy::DamageRange BombStrategy::s_damageRange(2, 5);

void BombStrategy::Draw()
{
    std::cout << "*";
}
void BombStrategy::OnEnter(Player* pPlayer)
{
    int damage = (rand() % (s_damageRange.second - s_damageRange.first)) + s_damageRange.first;
    pPlayer->Damage(damage);
    // Bombs become "Exploded" --> set new Strategy
    m_tile->SetStrategy(new ExplodedStrategy(m_tile));
}

//////////////////////////////////////////////////////////////
// Mimic Tile Strategy
//////////////////////////////////////////////////////////////
void MimicStrategy::Draw()
{
    std::cout << "$";
}

//////////////////////////////////////////////////////////////
// Exploded Tile Strategy
//////////////////////////////////////////////////////////////
void ExplodedStrategy::Draw()
{
    std::cout << "#";
}
void ExplodedStrategy::OnEnter(Player* pPlayer)
{
    // nothing
}
