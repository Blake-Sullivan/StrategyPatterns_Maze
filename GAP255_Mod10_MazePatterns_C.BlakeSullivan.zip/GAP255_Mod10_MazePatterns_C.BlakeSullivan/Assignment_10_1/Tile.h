// Tile.h
#ifndef __TILE_H__
#define __TILE_H__

#include "TileStrategy.h"
#include "World.h"

class Tile
{
private:
    TileStrategy* m_tileStrategy;
public:
    // Constructor will determine tile's behavior strategy.
    Tile(TileType tile);

    // Tile is being used as a base class, hence having a virtual destructor.
    ~Tile();

    // Allows Tiles to change their strategy and behavior.
    void SetStrategy(TileStrategy* strategy);

    // Draws the tile according to its strategy pointer.
    void Draw();

    // Behavior of the tile occurs when the player enters the tile.
    void OnEnter(Player* pPlayer);
};
#endif