#include "Tile.h"
#include "Player.h"


// Constructor will determine a tile's strategy.
Tile::Tile(TileType tile)
{
    switch (tile)
    {
    case TileType::k_end:
        m_tileStrategy = new EndStrategy(this);
        break;
    case TileType::k_floor:
        m_tileStrategy = new EmptyStrategy(this);
        break;
    case TileType::k_treasure:
        m_tileStrategy = new TreasureStrategy(this);
        break;
    case TileType::k_bomb:
        m_tileStrategy = new BombStrategy(this);
        break;
    case TileType::k_mimic:
        m_tileStrategy = new MimicStrategy(this);
        break;
    }
}

// Tile is being used as a base class, hence having a virtual destructor.
Tile::~Tile()
{
    if (m_tileStrategy = nullptr)
    {
        delete m_tileStrategy;
    }
}

// Allows Tiles to change their strategy and behavior.
void Tile::SetStrategy(TileStrategy* strategy)
{
    if (m_tileStrategy = nullptr)
    {
        delete m_tileStrategy;
    }
    m_tileStrategy = strategy;
}

// Draws the tile according to its strategy pointer.
void Tile::Draw()
{
    m_tileStrategy->Draw();
}

// Behavior of the tile occurs when the player enters the tile.
void Tile::OnEnter(Player* pPlayer)
{
    m_tileStrategy->OnEnter(pPlayer);
}
