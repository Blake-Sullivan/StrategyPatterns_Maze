#pragma once
#include <utility>
#include <iostream>

class Player;
class Tile;

// Strategy behavior pattern BASE CLASS  -  for types of tiles.
struct TileStrategy
{
    Tile* m_tile;

    virtual void Draw() = 0;
    virtual void OnEnter(Player* pPlayer) = 0;
    
    TileStrategy(Tile* tile);
};

// Strategy and behavior for a  -  Floor Tile.
class EmptyStrategy : public TileStrategy
{
public:
    EmptyStrategy(Tile* tile);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};

// Strategy and behavior for a  -  End Tile.
class EndStrategy : public TileStrategy
{
public:
    EndStrategy(Tile* tile);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};

// Strategy and behavior for a  -  Treasure Tile.
//  --> converts to an "EmptyStrategy" after player interaction.
class TreasureStrategy : public TileStrategy
{
private:
    typedef std::pair<int, int> TreasureRange;
    
    static const TreasureRange s_treasureRange; 
public: 
    TreasureStrategy(Tile* tile);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};

// Strategy and behavior for a  -  Bomb Tile.
//  --> converts to an "ExplodedStrategy" after player interaction.
class BombStrategy : public TileStrategy
{
private:
    typedef std::pair<int, int> DamageRange;
    static const DamageRange s_damageRange;

public:
    BombStrategy(Tile* tile);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};

// Strategy and behavior for a  -  Mimic Tile.  
//  --> Acts like a bomb tile, "Mimic is a Bomb", but Draws() like a Treasure Tile.
class MimicStrategy : public BombStrategy
{
public:
    MimicStrategy(Tile* tile);

    void Draw() override;
};

// Strategy and behavior for a  -  Tile that has exploded.
//  --> used by Bombs & Mimics.
class ExplodedStrategy : public TileStrategy
{
public:
    ExplodedStrategy(Tile* tile);

    void Draw() override;
    void OnEnter(Player* pPlayer) override;
};